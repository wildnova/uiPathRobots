El nombre de las colas de orchestrator es:
PRV_000_0000_practicaIkea
PRV_000_0100_practicaIkea

El asset con el correo y contraseña debe llamarse:
mail

Explicaciones de código:
El primer step PRV_000_0000_PracticaIkea lee del correo y guarda los adjuntos. Solo realiza una transacción.
El segundo step PRV_000_0100_PracticaIkea lee de la primera cola los datos y realiza la búsqueda en la web de ikea
El tercer step PRV_000_0200_PracticaIkea lee los datos de la segunda cola y en cada transacción escribe los datos en una fila de un Datatable hasta que al acabar las transacciones, en la línea de endprocess escribe los datos en el excel.
